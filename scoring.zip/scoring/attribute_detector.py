"""
Trust Stack Attribute Detector
Detects 36 Trust Stack attributes from normalized content metadata
"""
import json
import re
from typing import List, Dict, Optional
from urllib.parse import urlparse
import logging

from data.models import NormalizedContent, DetectedAttribute

# Import WHOIS lookup for domain trust signals
try:
    from ingestion.whois_lookup import get_whois_lookup, WHOIS_AVAILABLE
except ImportError:
    WHOIS_AVAILABLE = False
    def get_whois_lookup():
        return None

logger = logging.getLogger(__name__)


class TrustStackAttributeDetector:
    """Detects Trust Stack attributes from content metadata"""

    def __init__(self, rubric_path: str = "config/rubric.json"):
        """
        Initialize detector with rubric configuration

        Args:
            rubric_path: Path to rubric.json containing attribute definitions
        """
        with open(rubric_path, "r", encoding="utf-8") as f:
            self.rubric = json.load(f)

        # Load only enabled attributes
        self.attributes = {
            attr["id"]: attr
            for attr in self.rubric["attributes"]
            if attr.get("enabled", False)
        }

        logger.info(f"Loaded {len(self.attributes)} enabled Trust Stack attributes")

    def detect_attributes(self, content: NormalizedContent) -> List[DetectedAttribute]:
        """
        Detect all applicable Trust Stack attributes from content

        Args:
            content: Normalized content to analyze

        Returns:
            List of detected attributes with values 1-10
        """
        detected = []

        # Dispatch to specific detection methods
        detection_methods = {
            # Provenance
            "ai_vs_human_labeling_clarity": self._detect_ai_human_labeling,
            "author_brand_identity_verified": self._detect_author_verified,
            "c2pa_cai_manifest_present": self._detect_c2pa_manifest,
            "canonical_url_matches_declared_source": self._detect_canonical_url,
            "digital_watermark_fingerprint_detected": self._detect_watermark,
            "exif_metadata_integrity": self._detect_exif_integrity,
            "source_domain_trust_baseline": self._detect_domain_trust,
            "domain_age": self._detect_domain_age,
            "whois_privacy": self._detect_whois_privacy,
            "verified_platform_account": self._detect_platform_verification,

            # Resonance
            "community_alignment_index": self._detect_community_alignment,
            "creative_recency_vs_trend": self._detect_trend_alignment,
            "cultural_context_alignment": self._detect_cultural_context,
            "language_locale_match": self._detect_language_match,
            "personalization_relevance_embedding_similarity": self._detect_personalization,
            "readability_grade_level_fit": self._detect_readability,
            "tone_sentiment_appropriateness": self._detect_tone_sentiment,

            # Coherence
            "brand_voice_consistency_score": self._detect_brand_voice,
            "broken_link_rate": self._detect_broken_links,
            "claim_consistency_across_pages": self._detect_claim_consistency,
            "email_asset_consistency_check": self._detect_email_consistency,
            "engagement_to_trust_correlation": self._detect_engagement_trust,
            "multimodal_consistency_score": self._detect_multimodal_consistency,
            "temporal_continuity_versions": self._detect_temporal_continuity,
            "trust_fluctuation_index": self._detect_trust_fluctuation,

            # Transparency
            "ai_explainability_disclosure": self._detect_ai_explainability,
            "ai_generated_assisted_disclosure_present": self._detect_ai_disclosure,
            "bot_disclosure_response_audit": self._detect_bot_disclosure,
            "caption_subtitle_availability_accuracy": self._detect_captions,
            "data_source_citations_for_claims": self._detect_citations,
            "privacy_policy_link_availability_clarity": self._detect_privacy_policy,
            "contact_info_availability": self._detect_contact_info,

            # Verification
            "ad_sponsored_label_consistency": self._detect_ad_labels,
            "agent_safety_guardrail_presence": self._detect_safety_guardrails,
            "claim_to_source_traceability": self._detect_claim_traceability,
            "engagement_authenticity_ratio": self._detect_engagement_authenticity,
            "influencer_partner_identity_verified": self._detect_influencer_verified,
            "review_authenticity_confidence": self._detect_review_authenticity,
            "seller_product_verification_rate": self._detect_seller_verification,
            "verified_purchaser_review_rate": self._detect_verified_purchaser,

            # 
            "schema_compliance": self._detect_schema_compliance,
            "metadata_completeness": self._detect_metadata_completeness,
            "llm_retrievability": self._detect_llm_retrievability,
            "canonical_linking": self._detect_canonical_linking,
            "indexing_visibility": self._detect_indexing_visibility,
            "ethical_training_signals": self._detect_ethical_training_signals,
        }

        for attr_id, detection_func in detection_methods.items():
            if attr_id in self.attributes:
                try:
                    result = detection_func(content)
                    if result:
                        detected.append(result)
                except Exception as e:
                    logger.warning(f"Error detecting {attr_id}: {e}")

        return detected

    # ===== PROVENANCE DETECTORS =====

    def _detect_ai_human_labeling(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """
        Detect AI vs human labeling clarity - context-aware version.
        
        Only flags missing labeling when it's actually relevant:
        - Content appears to be AI-generated
        - Content type is blog/article/news (where authorship disclosure matters)
        - Content explicitly discusses AI topics
        
        Does NOT flag standard corporate pages, landing pages, product pages, etc.
        """
        text = (content.body + " " + content.title).lower()
        meta = content.meta or {}

        # Check for explicit AI/human labels
        ai_labels = ["ai-generated", "ai generated", "artificial intelligence", "generated by ai", "created with ai"]
        human_labels = ["human-created", "human created", "written by", "authored by"]

        has_ai_label = any(label in text for label in ai_labels)
        has_human_label = any(label in text for label in human_labels)
        has_meta_label = any(key in meta for key in ["ai_generated", "human_created", "author_type"])

        # If labeling is present, return positive result
        if has_ai_label or has_human_label or has_meta_label:
            return DetectedAttribute(
                attribute_id="ai_vs_human_labeling_clarity",
                dimension="provenance",
                label="AI vs Human Labeling Clarity",
                value=10.0,
                evidence="Clear labeling found in content or metadata",
                confidence=1.0
            )

        # Determine if AI labeling is relevant for this content
        content_type = self._determine_content_type(content)
        
        # Check for AI generation indicators
        ai_generation_indicators = [
            "as an ai", "i am an ai", "i'm an ai", "ai assistant", 
            "language model", "chatgpt", "gpt-4", "claude", "gemini",
            "generated summary", "ai-powered", "machine learning generated"
        ]
        has_ai_indicators = any(indicator in text for indicator in ai_generation_indicators)
        
        # Check if content discusses AI topics (but isn't necessarily AI-generated)
        ai_topic_keywords = [
            "artificial intelligence", "machine learning", "neural network", 
            "deep learning", "ai technology", "ai solution"
        ]
        discusses_ai = any(keyword in text for keyword in ai_topic_keywords)
        
        # Only flag as an issue if:
        # 1. Content shows AI generation indicators (likely AI-generated without disclosure)
        # 2. Content type is blog/article/news where authorship disclosure is important
        # 3. Content discusses AI extensively (ambiguous whether it's AI-generated)
        
        should_flag = False
        reason = ""
        
        if has_ai_indicators:
            # Content appears to be AI-generated but lacks labeling
            should_flag = True
            reason = "Content appears AI-generated but lacks disclosure"
        elif content_type in ['blog', 'article', 'news'] and not content.author:
            # Blog/article content without author attribution might benefit from AI/human labeling
            should_flag = True
            reason = "Blog/article content lacks author attribution or AI disclosure"
        elif discusses_ai and text.count("ai") > 5:
            # Content heavily discusses AI - ambiguous whether it's AI-generated
            should_flag = True
            reason = "Content discusses AI extensively without clarifying if AI-generated"
        
        # Only return an issue if we determined labeling is relevant
        if should_flag:
            return DetectedAttribute(
                attribute_id="ai_vs_human_labeling_clarity",
                dimension="provenance",
                label="AI vs Human Labeling Clarity",
                value=3.0,  # Moderate issue, not critical
                evidence=reason,
                confidence=0.7  # Lower confidence since we're inferring
            )
        
        # For corporate pages, landing pages, product pages, etc. - don't flag at all
        # Returning None means this attribute won't be reported as an issue
        return None

    def _detect_author_verified(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """
        Detect author/brand identity verification with content-type awareness.

        Blog posts and articles warrant visible bylines, but corporate landing pages
        showing organizational/team attribution through structured data or subtle
        footer credits can still pass the Author Identity check.
        
        Also checks for platform verification badges (Instagram, LinkedIn, X/Twitter)
        which indicate verified accounts with blue checkmarks.
        """
        meta = content.meta or {}

        # Determine content type
        content_type = self._determine_content_type(content)

        # Check for platform verification badges (from page_fetcher extraction)
        verification_badges = meta.get("verification_badges", {})
        if isinstance(verification_badges, dict) and verification_badges.get("verified"):
            platform = verification_badges.get("platform", "unknown")
            badge_type = verification_badges.get("badge_type", "verification_badge")
            evidence = verification_badges.get("evidence", "Platform verification detected")
            
            # Platform verification is high-confidence verification
            return DetectedAttribute(
                attribute_id="author_brand_identity_verified",
                dimension="provenance",
                label="Author/Brand Identity Verified",
                value=10.0,
                evidence=f"Platform verified ({platform}): {badge_type}. {evidence}",
                confidence=1.0
            )

        # Check for explicit verification (highest confidence)
        is_explicitly_verified = (
            meta.get("author_verified") == "true" or
            meta.get("verified") == "true" or
            "verified" in content.author.lower()
        )

        if is_explicitly_verified:
            return DetectedAttribute(
                attribute_id="author_brand_identity_verified",
                dimension="provenance",
                label="Author/Brand Identity Verified",
                value=10.0,
                evidence=f"Verified author: {content.author}",
                confidence=1.0
            )


        # Check for visible byline (expected for blog/article content)
        has_visible_byline = content.author and content.author.lower() not in ['unknown', 'anonymous', '']

        # If no metadata author, check body text for "By [Name]" pattern
        if not has_visible_byline:
            # Look for "By Name" at start of lines, allowing for some context
            # Limit to first 2000 chars to avoid false positives in comments/footer
            intro_text = content.body[:2000]
            byline_match = re.search(r'(?:^|\n)\s*By\s+([A-Z][a-zA-Z\s\.]+)(?:\s|$)', intro_text)
            if byline_match:
                detected_author = byline_match.group(1).strip()
                # Filter out common false positives
                if len(detected_author) < 30 and detected_author.lower() not in ['email', 'phone', 'clicking', 'using']:
                    has_visible_byline = True
                    # Optionally update content.author? No, keep content immutable here, just use for detection.
                    logger.info(f"Detected author in text: {detected_author}")

        # For blog/article content, require visible byline
        if content_type in ['blog', 'article', 'news']:
            if has_visible_byline:
                return DetectedAttribute(
                    attribute_id="author_brand_identity_verified",
                    dimension="provenance",
                    label="Author/Brand Identity Verified",
                    value=8.0,
                    evidence=f"Visible byline present: {content.author}",
                    confidence=0.9
                )
            else:
                # If no visible byline for blog/article/news, check for structured
                # attribution (schema.org, meta tags, footer credits). Some pages
                # embed author/publisher data in JSON-LD where the author may be
                # a simple string; consult alternative attribution before
                # failing the byline requirement.
                attribution_result = self._check_alternative_attribution(content, meta)

                if attribution_result['found']:
                    # Use the attribution score (schema author/publisher or meta tag)
                    return DetectedAttribute(
                        attribute_id="author_brand_identity_verified",
                        dimension="provenance",
                        label="Author/Brand Identity Verified",
                        value=attribution_result['score'],
                        evidence=attribution_result['evidence'],
                        confidence=attribution_result['confidence']
                    )
                else:
                    return DetectedAttribute(
                        attribute_id="author_brand_identity_verified",
                        dimension="provenance",
                        label="Author/Brand Identity Verified",
                        value=2.0,
                        evidence="Missing byline - expected for blog/article content",
                        confidence=1.0
                    )

        # For corporate landing pages, check alternative attribution methods
        elif content_type == 'landing_page':
            attribution_result = self._check_alternative_attribution(content, meta)

            if attribution_result['found']:
                return DetectedAttribute(
                    attribute_id="author_brand_identity_verified",
                    dimension="provenance",
                    label="Author/Brand Identity Verified",
                    value=attribution_result['score'],
                    evidence=attribution_result['evidence'],
                    confidence=attribution_result['confidence']
                )
            else:
                return DetectedAttribute(
                    attribute_id="author_brand_identity_verified",
                    dimension="provenance",
                    label="Author/Brand Identity Verified",
                    value=3.0,
                    evidence="No attribution found - consider adding structured data or footer credits",
                    confidence=0.8
                )

        # For other content types, check both approaches
        else:
            if has_visible_byline:
                return DetectedAttribute(
                    attribute_id="author_brand_identity_verified",
                    dimension="provenance",
                    label="Author/Brand Identity Verified",
                    value=7.0,
                    evidence=f"Author attribution present: {content.author}",
                    confidence=0.85
                )
            else:
                attribution_result = self._check_alternative_attribution(content, meta)
                if attribution_result['found']:
                    return DetectedAttribute(
                        attribute_id="author_brand_identity_verified",
                        dimension="provenance",
                        label="Author/Brand Identity Verified",
                        value=attribution_result['score'],
                        evidence=attribution_result['evidence'],
                        confidence=attribution_result['confidence']
                    )
                else:
                    return DetectedAttribute(
                        attribute_id="author_brand_identity_verified",
                        dimension="provenance",
                        label="Author/Brand Identity Verified",
                        value=3.0,
                        evidence="Author verification status unknown",
                        confidence=0.8
                    )

    def _determine_content_type(self, content: NormalizedContent) -> str:
        """
        Determine content type based on channel, URL patterns, and metadata.

        Returns:
            Content type: 'blog', 'article', 'news', 'landing_page', 'other'
        """
        url_lower = content.url.lower()

        # Check for blog/article/news patterns in URL
        blog_patterns = ['/blog/', '/article/', '/post/', '/news/', '/story/']
        if any(pattern in url_lower for pattern in blog_patterns):
            if '/blog/' in url_lower:
                return 'blog'
            elif '/news/' in url_lower or '/story/' in url_lower:
                return 'news'
            else:
                return 'article'

        # Check for landing page patterns
        landing_patterns = [
            url_lower.endswith('/'),  # Root or section homepage
            '/product/' in url_lower,
            '/solution/' in url_lower,
            '/service/' in url_lower,
            '/about' in url_lower,
            '/home' in url_lower
        ]
        if any(landing_patterns):
            return 'landing_page'

        # Check metadata for content type hints
        meta = content.meta or {}
        meta_type = meta.get('type', '').lower()
        if meta_type in ['article', 'blog', 'news', 'blogposting', 'newsarticle']:
            return meta_type

        # Check schema.org data
        schema_org = meta.get('schema_org')
        if schema_org:
            try:
                import json
                schema_data = json.loads(schema_org) if isinstance(schema_org, str) else schema_org
                if isinstance(schema_data, dict):
                    schema_type = schema_data.get('@type', '')
                    if isinstance(schema_type, str):
                        if 'Article' in schema_type or 'BlogPosting' in schema_type:
                            return 'blog' if 'Blog' in schema_type else 'article'
                        elif 'NewsArticle' in schema_type:
                            return 'news'
                        elif 'WebPage' in schema_type or 'Organization' in schema_type:
                            return 'landing_page'
            except:
                pass

        # Default based on channel
        if content.channel in ['reddit', 'twitter', 'facebook', 'instagram']:
            return 'social_post'
        elif content.channel in ['youtube', 'tiktok']:
            return 'video'

        return 'other'

    def _check_alternative_attribution(self, content: NormalizedContent, meta: Dict) -> Dict[str, any]:
        """
        Check for alternative attribution methods suitable for corporate landing pages.

        Looks for:
        - Structured data (schema.org author/contributor/publisher)
        - Meta author tags
        - Footer attribution indicators
        - About/credits page links

        Returns:
            Dict with keys: found (bool), score (float), evidence (str), confidence (float)
        """
        attribution_methods = []

        # Check schema.org structured data
        schema_org = meta.get('schema_org')
        if schema_org:
            try:
                import json
                schema_data = json.loads(schema_org) if isinstance(schema_org, str) else schema_org

                # Handle both single object and list of objects
                schema_list = schema_data if isinstance(schema_data, list) else [schema_data]

                for schema_item in schema_list:
                    if not isinstance(schema_item, dict):
                        continue

                    # Check for author
                    if 'author' in schema_item:
                        author = schema_item['author']
                        if isinstance(author, dict):
                            author_name = author.get('name', '')
                        else:
                            author_name = str(author)
                        if author_name:
                            attribution_methods.append(f"Schema.org author: {author_name}")

                    # Check for contributor
                    if 'contributor' in schema_item:
                        contributor = schema_item['contributor']
                        if isinstance(contributor, dict):
                            contrib_name = contributor.get('name', '')
                        else:
                            contrib_name = str(contributor)
                        if contrib_name:
                            attribution_methods.append(f"Schema.org contributor: {contrib_name}")

                    # Check for publisher
                    if 'publisher' in schema_item:
                        publisher = schema_item['publisher']
                        if isinstance(publisher, dict):
                            pub_name = publisher.get('name', '')
                        else:
                            pub_name = str(publisher)
                        if pub_name:
                            attribution_methods.append(f"Schema.org publisher: {pub_name}")
            except:
                pass

        # Check meta author tag
        meta_author = meta.get('author')
        if meta_author and meta_author.lower() not in ['unknown', 'anonymous', '']:
            attribution_methods.append(f"Meta author tag: {meta_author}")

        # Check for footer attribution indicators in meta
        footer_indicators = ['maintained_by', 'content_by', 'team', 'department']
        for indicator in footer_indicators:
            if indicator in meta and meta[indicator]:
                attribution_methods.append(f"Footer attribution: {meta[indicator]}")

        # Check for about/credits page links in meta
        about_links = ['about_url', 'credits_url', 'team_url']
        for link_key in about_links:
            if link_key in meta and meta[link_key]:
                attribution_methods.append(f"Credits page available: {meta[link_key]}")

        # Determine score based on attribution methods found
        if not attribution_methods:
            return {
                'found': False,
                'score': 3.0,
                'evidence': '',
                'confidence': 0.8
            }

        # Score based on type and quantity of attribution
        if any('Schema.org author:' in method for method in attribution_methods):
            score = 8.0
            confidence = 0.95
        elif any('Meta author tag:' in method for method in attribution_methods):
            score = 7.0
            confidence = 0.9
        elif any('Schema.org publisher:' in method or 'Schema.org contributor:' in method for method in attribution_methods):
            score = 7.0
            confidence = 0.9
        elif any('Footer attribution:' in method for method in attribution_methods):
            score = 6.0
            confidence = 0.85
        elif any('Credits page' in method for method in attribution_methods):
            score = 6.0
            confidence = 0.8
        else:
            score = 5.0
            confidence = 0.75

        evidence = "Alternative attribution found: " + "; ".join(attribution_methods[:2])  # Limit evidence length

        return {
            'found': True,
            'score': score,
            'evidence': evidence,
            'confidence': confidence
        }

    def _detect_c2pa_manifest(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect C2PA/CAI manifest presence"""
        meta = content.meta or {}

        has_c2pa = any(key in meta for key in ["c2pa_manifest", "cai_manifest", "content_credentials"])

        if has_c2pa:
            is_valid = meta.get("c2pa_valid") != "false"
            value = 10.0 if is_valid else 5.0
            evidence = "C2PA manifest present and valid" if is_valid else "C2PA manifest present but invalid"
            return DetectedAttribute(
                attribute_id="c2pa_cai_manifest_present",
                dimension="provenance",
                label="C2PA/CAI Manifest Present",
                value=value,
                evidence=evidence,
                confidence=1.0
            )
        else:
            return DetectedAttribute(
                attribute_id="c2pa_cai_manifest_present",
                dimension="provenance",
                label="C2PA/CAI Manifest Present",
                value=1.0,
                evidence="No C2PA manifest found",
                confidence=1.0
            )

    def _detect_canonical_url(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect canonical URL match"""
        meta = content.meta or {}
        canonical_url = meta.get("canonical_url", "")

        if not canonical_url:
            return None  # Can't determine without canonical URL

        # Parse both URLs
        try:
            canonical_domain = urlparse(canonical_url).netloc
            source_domain = urlparse(meta.get("url", "")).netloc

            if canonical_domain == source_domain:
                value = 10.0
                evidence = "Canonical URL matches source domain"
            elif canonical_domain in source_domain or source_domain in canonical_domain:
                value = 5.0
                evidence = "Partial canonical URL match"
            else:
                value = 1.0
                evidence = "Canonical URL mismatch"

            return DetectedAttribute(
                attribute_id="canonical_url_matches_declared_source",
                dimension="provenance",
                label="Canonical URL Matches Declared Source",
                value=value,
                evidence=evidence,
                confidence=1.0
            )
        except Exception:
            return None

    def _detect_watermark(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect digital watermark/fingerprint"""
        meta = content.meta or {}

        has_watermark = any(key in meta for key in ["watermark", "fingerprint", "digital_signature"])

        if has_watermark:
            return DetectedAttribute(
                attribute_id="digital_watermark_fingerprint_detected",
                dimension="provenance",
                label="Digital Watermark/Fingerprint Detected",
                value=10.0,
                evidence="Watermark detected in metadata",
                confidence=1.0
            )
        return None  # Only report if found

    def _detect_exif_integrity(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect EXIF/metadata integrity"""
        meta = content.meta or {}

        if "exif_data" in meta:
            exif_status = meta.get("exif_status", "intact")

            if exif_status == "intact":
                value = 10.0
                evidence = "EXIF metadata intact"
            elif exif_status == "stripped":
                value = 5.0
                evidence = "EXIF metadata stripped"
            else:  # spoofed
                value = 1.0
                evidence = "EXIF metadata spoofed"

            return DetectedAttribute(
                attribute_id="exif_metadata_integrity",
                dimension="provenance",
                label="EXIF/Metadata Integrity",
                value=value,
                evidence=evidence,
                confidence=1.0
            )
        return None

    def _detect_domain_trust(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect source domain trust baseline"""
        meta = content.meta or {}

        # Simple domain reputation based on source
        domain = meta.get("domain", "")
        source = content.src.lower()

        # Trusted platforms get higher scores
        trusted_sources = {
            "reddit": 7.0,
            "youtube": 7.0,
            "amazon": 8.0,
        }

        # Known high-trust domains
        trusted_domains = [
            ".gov", ".edu", ".org",
            "nytimes.com", "wsj.com", "bbc.com", "reuters.com"
        ]

        # Check for red flags
        red_flags = []
        if meta.get("ssl_valid") == "false":
            red_flags.append("No valid SSL certificate")
        if meta.get("has_privacy_policy") == "false":
            red_flags.append("No privacy policy found")
        if meta.get("domain_age_days") and int(meta.get("domain_age_days", 999)) < 30:
            red_flags.append("Very new domain (less than 30 days old)")
        if meta.get("malware_detected") == "true":
            red_flags.append("Malware detected")
        if meta.get("spam_score") and float(meta.get("spam_score", 0)) > 7.0:
            red_flags.append("High spam score")

        # If there are red flags, report low trust
        if red_flags:
            return DetectedAttribute(
                attribute_id="source_domain_trust_baseline",
                dimension="provenance",
                label="Source Domain Trust Baseline",
                value=2.0,
                evidence=f"Domain trust issues: {'; '.join(red_flags)}",
                confidence=0.9
            )

        # Report only trusted sources/domains positively
        # Don't report neutral cases - they're not issues
        if source in trusted_sources:
            value = trusted_sources[source]
            evidence = f"Trusted platform: {source}"
            return DetectedAttribute(
                attribute_id="source_domain_trust_baseline",
                dimension="provenance",
                label="Source Domain Trust Baseline",
                value=value,
                evidence=evidence,
                confidence=0.8
            )
        elif any(domain.endswith(td) for td in trusted_domains):
            value = 9.0
            evidence = f"High-trust domain: {domain}"
            return DetectedAttribute(
                attribute_id="source_domain_trust_baseline",
                dimension="provenance",
                label="Source Domain Trust Baseline",
                value=value,
                evidence=evidence,
                confidence=0.8
            )
        else:
            # Neutral case - don't report as an issue
            return None

    def _detect_domain_age(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """
        Detect domain age using WHOIS lookup.
        
        Older domains are generally more trustworthy. This is a strong
        provenance signal that helps identify fly-by-night operations
        vs established organizations.
        """
        if not WHOIS_AVAILABLE:
            return None
        
        # Get URL from content
        url = content.url
        if not url:
            return None
        
        # Only do WHOIS lookup for web sources, not social platforms
        # Social platforms (reddit, youtube, etc.) have their own trust baselines
        if content.src.lower() in ['reddit', 'youtube', 'twitter', 'facebook', 'instagram', 'tiktok', 'amazon']:
            return None
        
        try:
            whois_lookup = get_whois_lookup()
            if not whois_lookup or not whois_lookup.available:
                return None
            
            result = whois_lookup.lookup(url)
            
            if 'error' in result:
                logger.debug(f"WHOIS lookup failed for {url}: {result['error']}")
                return None
            
            signals = result.get('trust_signals', {})
            age_score = signals.get('domain_age_score')
            
            if age_score is None:
                return None
            
            age_years = result.get('domain_age_years')
            assessment = signals.get('domain_age_assessment', '')
            
            # Store WHOIS data in content meta for other detectors
            if hasattr(content, 'meta') and content.meta is not None:
                content.meta['whois_domain_age_years'] = age_years
                content.meta['whois_domain_age_days'] = result.get('domain_age_days')
                content.meta['whois_registrar'] = result.get('registrar')
            
            return DetectedAttribute(
                attribute_id="domain_age",
                dimension="provenance",
                label="Domain Age",
                value=age_score,
                evidence=f"Domain age: {age_years} years. {assessment}",
                confidence=0.9
            )
            
        except Exception as e:
            logger.warning(f"Error detecting domain age for {url}: {e}")
            return None

    def _detect_whois_privacy(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """
        Detect WHOIS privacy/proxy registration.
        
        WHOIS privacy services hide the registrant's identity. While legitimate
        for personal privacy, it can be a yellow flag for commercial sites
        where transparency is expected.
        """
        if not WHOIS_AVAILABLE:
            return None
        
        # Get URL from content
        url = content.url
        if not url:
            return None
        
        # Only do WHOIS lookup for web sources
        if content.src.lower() in ['reddit', 'youtube', 'twitter', 'facebook', 'instagram', 'tiktok', 'amazon']:
            return None
        
        try:
            whois_lookup = get_whois_lookup()
            if not whois_lookup or not whois_lookup.available:
                return None
            
            result = whois_lookup.lookup(url)
            
            if 'error' in result:
                return None
            
            signals = result.get('trust_signals', {})
            privacy_score = signals.get('privacy_score')
            
            if privacy_score is None:
                return None
            
            has_privacy = result.get('whois_privacy', False)
            assessment = signals.get('privacy_assessment', '')
            registrant_org = result.get('registrant_org')
            
            # Store in content meta
            if hasattr(content, 'meta') and content.meta is not None:
                content.meta['whois_privacy'] = has_privacy
                content.meta['whois_registrant_org'] = registrant_org
            
            # Only report if privacy is enabled (a potential flag)
            # or if we have a clear positive signal (visible registration)
            if has_privacy:
                return DetectedAttribute(
                    attribute_id="whois_privacy",
                    dimension="provenance",
                    label="WHOIS Privacy Status",
                    value=privacy_score,
                    evidence=f"WHOIS privacy enabled - registrant identity hidden. {assessment}",
                    confidence=0.85
                )
            elif registrant_org:
                return DetectedAttribute(
                    attribute_id="whois_privacy",
                    dimension="provenance",
                    label="WHOIS Privacy Status",
                    value=privacy_score,
                    evidence=f"Registrant publicly visible: {registrant_org}",
                    confidence=0.9
                )
            else:
                # Neutral case - no privacy but also no org info
                return None
            
        except Exception as e:
            logger.warning(f"Error detecting WHOIS privacy for {url}: {e}")
            return None

    def _detect_platform_verification(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """
        Detect platform verification badges for social media accounts.
        
        This creates a dedicated attribute that maps to 'Verification & Identity'
        key signal, separate from author verification. Detects blue checkmarks
        and verified status on Instagram, LinkedIn, X/Twitter, etc.
        """
        meta = content.meta or {}
        
        # Check for platform verification badges extracted by page_fetcher
        verification_badges = meta.get("verification_badges", {})
        
        if isinstance(verification_badges, dict) and verification_badges.get("verified"):
            platform = verification_badges.get("platform", "unknown")
            badge_type = verification_badges.get("badge_type", "verification_badge")
            evidence = verification_badges.get("evidence", "Platform verification detected")
            
            # Platform verification is high-confidence
            return DetectedAttribute(
                attribute_id="verified_platform_account",
                dimension="provenance",
                label="Verified Platform Account",
                value=10.0,
                evidence=f"Verified {platform} account: {badge_type}. {evidence}",
                confidence=1.0
            )
        
        # Check if this is a known social media platform without verification
        url_lower = content.url.lower() if content.url else ""
        social_platforms = ['instagram.com', 'linkedin.com', 'twitter.com', 'x.com', 'facebook.com', 'tiktok.com']
        
        is_social = any(platform in url_lower for platform in social_platforms)
        
        if is_social:
            # Social media without detected verification badge
            return DetectedAttribute(
                attribute_id="verified_platform_account",
                dimension="provenance",
                label="Verified Platform Account", 
                value=3.0,
                evidence="Social media profile without verified badge detected",
                confidence=0.7
            )
        
        # Not a social media platform - don't report (not applicable)
        return None

    # ===== RESONANCE DETECTORS =====

    def _detect_community_alignment(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect community alignment index (placeholder)"""
        # TODO: Implement hashtag/mention graph analysis
        return None

    def _detect_trend_alignment(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect creative recency vs trend (placeholder)"""
        # TODO: Implement trend API integration
        return None

    def _detect_cultural_context(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect cultural context alignment (placeholder)"""
        # TODO: Implement NER + cultural knowledge base
        return None

    def _detect_language_match(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect language/locale match"""
        meta = content.meta or {}
        detected_lang = meta.get("language", "en")

        # Assume English is target for now
        target_lang = "en"
        
        # Default to match if language is missing or matches target
        # This ensures we don't penalize content just because language detection failed or wasn't run
        if not detected_lang or detected_lang == target_lang:
            value = 10.0
            evidence = f"Language match: {detected_lang or 'en'}"
        else:
            value = 1.0
            evidence = f"Language mismatch: {detected_lang} (expected: {target_lang})"

        return DetectedAttribute(
            attribute_id="language_locale_match",
            dimension="resonance",
            label="Language/Locale Match",
            value=value,
            evidence=evidence,
            confidence=0.9
        )

    def _detect_personalization(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect personalization relevance (placeholder)"""
        # TODO: Implement embedding similarity
        return None

    def _detect_readability(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect readability grade level fit"""
        text = content.body

        # Simple readability heuristic (words per sentence)
        if not text or len(text) < 50:
            return None

        # Count total words
        words = len(text.split())
        
        # First, try traditional sentence splitting (periods, exclamation, question marks)
        # Use a more robust regex that handles multiple punctuation marks
        sentence_list = re.split(r'(?<=[\.\!\?])\s+', text)
        sentence_list = [s.strip() for s in sentence_list if len(s.strip()) > 0]

        # Secondary pass: Check for "run-on" sentences that are actually lists or unpunctuated blocks
        refined_sentence_list = []
        for sentence in sentence_list:
            # If a sentence is very long (> 50 words) and contains newlines, it might be a list or block
            if len(sentence.split()) > 50 and '\n' in sentence:
                # Split by newlines
                lines = [line.strip() for line in sentence.split('\n') if line.strip()]
                refined_sentence_list.extend(lines)
            else:
                refined_sentence_list.append(sentence)
        
        sentence_list = refined_sentence_list

        # Filter out "list-like" items from the sentence count
        # Heuristic: Real sentences usually have at least 5 words. 
        # Very short lines in a long block are likely list items (navigation, product names, etc.)
        # We keep them if they end in punctuation, otherwise we treat them as fragments to ignore
        # or count as short sentences depending on context.
        # Here, we'll filter out very short fragments (< 5 words) that don't end in punctuation
        # to avoid skewing the count with "Home", "About", "Contact", etc.
        
        final_sentences = []
        for s in sentence_list:
            word_count = len(s.split())
            if word_count < 5 and not s[-1] in ['.', '!', '?']:
                continue # Skip short fragments
            final_sentences.append(s)
            
        sentence_list = final_sentences

        # If we have very few sentences for the amount of text, try splitting on newlines too
        # This handles product pages, navigation, lists, etc.
        if len(sentence_list) < 3 and words > 100:
            # Try splitting on newlines as well
            line_list = [line.strip() for line in text.split('\n') if len(line.strip()) > 10]
            
            # Check if this looks like list/navigation content (many short lines)
            if len(line_list) > 3:  # Lowered from 5 to catch more list cases
                avg_line_length = sum(len(line.split()) for line in line_list) / len(line_list)
                
                # If average line is very short (< 10 words), this is likely navigation/lists, not prose
                if avg_line_length < 10:
                    return None  # Skip readability analysis for non-prose content
            
            # Use lines as sentences if we have more lines than traditional sentences
            if len(line_list) > len(sentence_list):
                sentence_list = line_list
        
        # Additional check: if we have very few sentences but the text has many newlines,
        # it's likely list/navigation content even if it doesn't meet the > 100 words threshold
        if len(sentence_list) <= 1 and words > 20:
            newline_count = text.count('\n')
            # If there are many newlines relative to the text (> 1 newline per 10 words), skip
            if newline_count > words / 10:
                return None

        if len(sentence_list) == 0:
            return None

        # Calculate words per sentence for each sentence
        sentence_word_counts = [len(s.split()) for s in sentence_list]
        
        # Use median instead of mean to be robust against outliers
        sentence_word_counts.sort()
        n = len(sentence_word_counts)
        if n == 0:
            return None
            
        if n % 2 == 0:
            median_words = (sentence_word_counts[n//2 - 1] + sentence_word_counts[n//2]) / 2
        else:
            median_words = sentence_word_counts[n//2]
        
        # Also calculate mean for comparison
        mean_words = sum(sentence_word_counts) / len(sentence_word_counts)
        
        # Use median as the primary metric (more robust)
        words_per_sentence = median_words

        # Target: 15-20 words per sentence (grade 8-10)
        if 12 <= words_per_sentence <= 22:
            value = 10.0
            evidence = f"Readable: {words_per_sentence:.1f} words/sentence"
        elif 8 <= words_per_sentence <= 30:
            value = 7.0
            evidence = f"Acceptable: {words_per_sentence:.1f} words/sentence"
        else:
            value = 4.0
            evidence = f"Difficult: {words_per_sentence:.1f} words/sentence"

        return DetectedAttribute(
            attribute_id="readability_grade_level_fit",
            dimension="resonance",
            label="Readability Grade Level Fit",
            value=value,
            evidence=evidence,
            confidence=0.7
        )

    def _detect_tone_sentiment(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect tone & sentiment appropriateness (placeholder)"""
        # TODO: Integrate sentiment analysis model
        return None

    # ===== COHERENCE DETECTORS =====

    def _detect_brand_voice(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect brand voice consistency"""
        # Simple heuristic: Check for professional tone markers vs casual/slang
        text = (content.body + " " + content.title).lower()
        
        # Slang/casual markers that might violate professional brand voice
        casual_markers = ["gonna", "wanna", "lol", "lmao", "omg", "thx", "u", "ur", "cuz"]
        found_markers = [m for m in casual_markers if f" {m} " in text]
        
        if found_markers:
            return DetectedAttribute(
                attribute_id="brand_voice_consistency_score",
                dimension="coherence",
                label="Brand Voice Consistency Score",
                value=4.0,
                evidence=f"Inconsistent brand voice detected (casual markers: {', '.join(found_markers[:3])})",
                confidence=0.7
            )
            
        # Positive signal: No slang found implies professional voice
        return DetectedAttribute(
            attribute_id="brand_voice_consistency_score",
            dimension="coherence",
            label="Brand Voice Consistency Score",
            value=10.0,
            evidence="Professional brand voice maintained (no casual markers detected)",
            confidence=0.6
        )

    def _detect_broken_links(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect broken link rate"""
        text = content.body + " " + content.title

        # Find URLs in text
        urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text)

        if not urls:
            return None  # No links to check

        # Check metadata for broken link info
        meta = content.meta or {}
        broken_count = int(meta.get("broken_links", 0))
        total_count = len(urls)

        if broken_count == 0:
            value = 10.0
            evidence = f"No broken links ({total_count} total)"
        else:
            broken_rate = broken_count / total_count
            if broken_rate < 0.01:
                value = 10.0
            elif broken_rate < 0.05:
                value = 7.0
            elif broken_rate < 0.10:
                value = 4.0
            else:
                value = 1.0
            evidence = f"{broken_count}/{total_count} broken links ({broken_rate:.1%})"

        return DetectedAttribute(
            attribute_id="broken_link_rate",
            dimension="coherence",
            label="Broken Link Rate",
            value=value,
            evidence=evidence,
            confidence=0.8
        )

    def _detect_claim_consistency(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect claim consistency across pages"""
        # Heuristic: Check for contradictory terms in close proximity
        text = content.body.lower()
        
        contradictions = [
            ("always", "never"),
            ("100%", "some"),
            ("free", "paid"),
            ("guaranteed", "estimated")
        ]
        
        for term1, term2 in contradictions:
            if term1 in text and term2 in text:
                # Check distance
                idx1 = text.find(term1)
                idx2 = text.find(term2)
                if abs(idx1 - idx2) < 100:  # Close proximity
                    return DetectedAttribute(
                        attribute_id="claim_consistency_across_pages",
                        dimension="coherence",
                        label="Claim Consistency Across Pages",
                        value=3.0,
                        evidence=f"Potential contradiction detected: '{term1}' vs '{term2}'",
                        confidence=0.6
                    )
        return None  # No contradictions detected

    def _detect_email_consistency(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect email-asset consistency"""
        # Only relevant for email content
        if content.channel != 'email':
            return None
            
        # Check if email content matches landing page (simulated via metadata)
        meta = content.meta or {}
        if meta.get('landing_page_match') == 'false':
            return DetectedAttribute(
                attribute_id="email_asset_consistency_check",
                dimension="coherence",
                label="Email-Asset Consistency Check",
                value=2.0,
                evidence="Email content contradicts landing page offer",
                confidence=0.9
            )
        return None

    def _detect_engagement_trust(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect engagement-to-trust correlation"""
        # Skip detection for content types where engagement metrics aren't applicable
        if not self._should_have_engagement_metrics(content):
            return None

        # Use engagement metrics as proxy
        upvotes = content.upvotes or 0
        rating = content.rating or 0.0

        # Only flag if there's actually concerning engagement patterns
        # Don't flag pages with zero engagement - that's normal for many pages
        if upvotes == 0 and rating == 0.0:
            return None  # No engagement data available, skip

        # High engagement + high rating = high trust
        if upvotes > 50 and rating > 4.0:
            value = 10.0
            evidence = f"High engagement ({upvotes} upvotes, {rating:.1f} rating)"
        elif upvotes > 10 and rating > 3.0:
            value = 7.0
            evidence = f"Moderate engagement ({upvotes} upvotes, {rating:.1f} rating)"
        elif upvotes > 5 or rating > 2.0:
            value = 6.0
            evidence = f"Moderate engagement ({upvotes} upvotes, {rating:.1f} rating)"
        else:
            # Only flag as concerning if there's negative engagement (low rating with votes)
            if rating < 2.0 and (upvotes > 5 or rating > 0):
                value = 3.0
                evidence = f"Low trust with engagement present ({upvotes} upvotes, {rating:.1f} rating)"
            else:
                return None  # Skip neutral cases

        return DetectedAttribute(
            attribute_id="engagement_to_trust_correlation",
            dimension="coherence",
            label="Engagement-to-Trust Correlation",
            value=value,
            evidence=evidence,
            confidence=0.6
        )

    def _should_have_engagement_metrics(self, content: NormalizedContent) -> bool:
        """
        Determine if engagement metrics (upvotes, ratings) are expected for this content type.

        Returns False for:
        - Job boards and career sites
        - Corporate websites and landing pages
        - Documentation and knowledge bases
        - News sites (unless they have commenting systems)
        - Government and educational sites
        - Static informational pages

        Returns True for:
        - Social media platforms (reddit, youtube, instagram, tiktok)
        - Marketplaces with reviews (amazon, etsy, yelp)
        - Community forums and discussion boards
        - Review platforms
        """
        # Social platforms and marketplaces always have engagement features
        engagement_channels = {'reddit', 'youtube', 'amazon', 'instagram', 'tiktok',
                              'facebook', 'twitter', 'yelp', 'tripadvisor', 'etsy'}
        if content.channel.lower() in engagement_channels:
            return True

        # Platform types that typically have engagement
        if content.platform_type.lower() in {'social', 'marketplace'}:
            return True

        # Check URL patterns for non-engagement sites
        url_lower = content.url.lower()

        # Job boards and career sites
        job_patterns = ['careers.', 'jobs.', '/careers/', '/jobs/', 'apply.',
                       'greenhouse.io', 'lever.co', 'workday.com', 'taleo.net',
                       'jobvite.com', 'indeed.com', 'linkedin.com/jobs']
        if any(pattern in url_lower for pattern in job_patterns):
            return False

        # Corporate landing pages and marketing sites
        if content.platform_type.lower() == 'owned' and content.source_type.lower() == 'brand_owned':
            # Brand-owned content typically doesn't have engagement features
            # unless it's explicitly a community or review section
            if not any(keyword in url_lower for keyword in ['/reviews/', '/community/', '/forum/', '/comments/']):
                return False

        # Documentation and knowledge bases
        doc_patterns = ['docs.', '/docs/', '/documentation/', 'developer.', '/api/',
                       'help.', '/help/', 'support.', '/kb/', 'wiki.']
        if any(pattern in url_lower for pattern in doc_patterns):
            return False

        # Government and educational sites (typically informational)
        if any(domain in url_lower for domain in ['.gov', '.edu', '.mil']):
            return False

        # Default to True if we can't determine - let the metric run
        # This is conservative: we'd rather have false positives than miss real engagement issues
        return True

    def _detect_multimodal_consistency(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect multimodal consistency (placeholder)"""
        # TODO: Implement caption vs transcript comparison
        return None

    def _detect_temporal_continuity(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect temporal continuity (placeholder)"""
        # TODO: Check version history metadata
        return None

    def _detect_trust_fluctuation(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect trust fluctuation index (placeholder)"""
        # TODO: Implement time-series sentiment analysis
        return None

    # ===== TRANSPARENCY DETECTORS =====

    def _detect_ai_explainability(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect AI explainability disclosure"""
        text = (content.body + " " + content.title).lower()
        meta = content.meta or {}

        # First, check if the page actually uses AI features
        ai_feature_indicators = [
            "artificial intelligence", "machine learning", "ai-powered", "ai powered",
            "personalized", "personalisation", "recommendation", "recommendations",
            "smart", "intelligent", "automated", "chatbot", "virtual assistant",
            "predicted", "prediction", "algorithm", "algorithmic"
        ]

        # Check if page uses AI
        uses_ai = (
            any(indicator in text for indicator in ai_feature_indicators) or
            meta.get("uses_ai") == "true" or
            meta.get("has_recommendations") == "true"
        )

        # Only check for explainability if AI is being used
        if not uses_ai:
            return None  # Page doesn't use AI, no disclosure needed

        # If AI is used, check for explainability
        explainability_phrases = [
            "why you're seeing this",
            "how this works",
            "how we recommend",
            "how we personalize",
            "learn more about our recommendations",
            "about our algorithm",
            "transparency",
            "explain"
        ]

        has_explainability = any(phrase in text for phrase in explainability_phrases)

        if has_explainability:
            return DetectedAttribute(
                attribute_id="ai_explainability_disclosure",
                dimension="transparency",
                label="AI Explainability Disclosure",
                value=10.0,
                evidence="Explainability disclosure found for AI features",
                confidence=0.9
            )
        else:
            return DetectedAttribute(
                attribute_id="ai_explainability_disclosure",
                dimension="transparency",
                label="AI Explainability Disclosure",
                value=2.0,
                evidence="AI features detected but no explainability disclosure",
                confidence=0.8
            )

    def _detect_ai_disclosure(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect AI-generated/assisted disclosure"""
        text = (content.body + " " + content.title).lower()
        meta = content.meta or {}

        ai_disclosure_phrases = [
            "ai-generated", "ai generated",
            "ai-assisted", "ai assisted",
            "generated by ai",
            "created with ai"
        ]

        has_disclosure = (
            any(phrase in text for phrase in ai_disclosure_phrases) or
            meta.get("ai_generated") == "true"
        )

        if has_disclosure:
            return DetectedAttribute(
                attribute_id="ai_generated_assisted_disclosure_present",
                dimension="transparency",
                label="AI-Generated/Assisted Disclosure Present",
                value=10.0,
                evidence="AI disclosure present",
                confidence=1.0
            )
        else:
            return DetectedAttribute(
                attribute_id="ai_generated_assisted_disclosure_present",
                dimension="transparency",
                label="AI-Generated/Assisted Disclosure Present",
                value=1.0,
                evidence="No AI disclosure",
                confidence=1.0
            )

    def _detect_bot_disclosure(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect bot disclosure (placeholder)"""
        # TODO: Check for bot self-identification
        return None

    def _detect_captions(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect caption/subtitle availability"""
        meta = content.meta or {}

        # Only applicable to video content
        if content.src != "youtube":
            return None

        has_captions = meta.get("has_captions") == "true"

        if has_captions:
            return DetectedAttribute(
                attribute_id="caption_subtitle_availability_accuracy",
                dimension="transparency",
                label="Caption/Subtitle Availability & Accuracy",
                value=10.0,
                evidence="Captions available",
                confidence=1.0
            )
        else:
            return DetectedAttribute(
                attribute_id="caption_subtitle_availability_accuracy",
                dimension="transparency",
                label="Caption/Subtitle Availability & Accuracy",
                value=1.0,
                evidence="No captions found",
                confidence=1.0
            )

    def _detect_citations(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect data source citations"""
        text = content.body

        # First, check if the page actually has data-driven claims that need citations
        data_claim_indicators = [
            r'\d+%',  # Percentages: 50%
            r'\$[\d,]+',  # Dollar amounts: $1,000
            r'\d+\s*million',  # Large numbers: 5 million
            r'\d+\s*billion',
            r'\d+\s*thousand',
            r'study\s+(?:found|shows|revealed)',
            r'research\s+(?:found|shows|revealed)',
            r'survey\s+(?:found|shows|revealed)',
            r'statistics?\s+(?:show|indicate)',
            r'data\s+(?:show|indicate)',
            r'according\s+to\s+(?:a\s+)?(?:study|research|survey|report)',
            r'findings?\s+(?:from|of)',
            r'results?\s+(?:from|of)',
        ]

        # Check if content has data-driven claims
        has_data_claims = any(re.search(pattern, text, re.IGNORECASE) for pattern in data_claim_indicators)

        # Skip pages without data claims
        if not has_data_claims:
            return None

        # Content has data claims, now check for citations
        citation_patterns = [
            r'\[\d+\]',  # [1], [2], etc.
            r'\(\w+,? \d{4}\)',  # (Author, 2024)
            r'according to\s+[\w\s]+(?:University|Institute|Organization|Agency|Department)',
            r'source:\s*[\w\s]+',
            r'cited by',
            r'study by',
            r'research by',
            r'report by'
        ]

        has_citations = any(re.search(pattern, text, re.IGNORECASE) for pattern in citation_patterns)

        if has_citations:
            return DetectedAttribute(
                attribute_id="data_source_citations_for_claims",
                dimension="transparency",
                label="Data Source Citations for Claims",
                value=10.0,
                evidence="Citations found for data claims",
                confidence=0.85
            )
        else:
            return DetectedAttribute(
                attribute_id="data_source_citations_for_claims",
                dimension="transparency",
                label="Data Source Citations for Claims",
                value=2.0,
                evidence="Data claims detected but no citations provided",
                confidence=0.8
            )

    def _detect_privacy_policy(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect privacy policy link"""
        text = (content.body + " " + content.title).lower()
        meta = content.meta or {}

        # Check for privacy policy in multiple ways
    
        # 0. Check if the page ITSELF is a privacy policy
        # If the URL contains "privacy" or "legal", it's likely the policy itself
        if "privacy" in content.url.lower() or "legal" in content.url.lower() or "terms" in content.url.lower():
             return DetectedAttribute(
                attribute_id="privacy_policy_link_availability_clarity",
                dimension="transparency",
                label="Privacy Policy Link Availability & Clarity",
                value=10.0,
                evidence="Page appears to be a privacy policy or legal page",
                confidence=0.95
            )

        # 1. Check metadata for privacy policy URL
        has_privacy_url = any(key in meta for key in [
            "privacy_policy_url", "privacy_url", "privacy_policy_link"
        ])

        # 2. Check for common privacy policy link text variations
        privacy_link_patterns = [
            "privacy policy",
            "privacy notice",
            "privacy statement",
            "data protection",
            "privacy & terms",
            "privacy and terms",
            "cookie policy",
            "privacy center",
            "your privacy",
            "legal",
            "terms of use",
            "terms of service",
            "cookie preferences",
            "cookie settings",
            "personal information",
            "data privacy",
            "legal notice"
        ]

        has_privacy_text = any(pattern in text for pattern in privacy_link_patterns)

        # 3. Check for /privacy or similar URL patterns in the text
        privacy_url_patterns = [
            "/privacy",
            "/privacy-policy",
            "/legal/privacy",
            "/privacy-notice",
            "/legal",
            "/terms"
        ]

        has_privacy_url_pattern = any(pattern in text for pattern in privacy_url_patterns)

        # Determine if privacy policy is present
        if has_privacy_url or has_privacy_text or has_privacy_url_pattern:
            return DetectedAttribute(
                attribute_id="privacy_policy_link_availability_clarity",
                dimension="transparency",
                label="Privacy Policy Link Availability & Clarity",
                value=10.0,
                evidence="Privacy policy link found",
                confidence=0.9
            )

        # Only flag as missing for owned/corporate content where privacy policy is expected
        # Don't flag social media posts, marketplace listings, etc.
        content_type = self._determine_content_type(content)
        if content_type in ['landing_page', 'other'] and content.platform_type.lower() == 'owned':
            return DetectedAttribute(
                attribute_id="privacy_policy_link_availability_clarity",
                dimension="transparency",
                label="Privacy Policy Link Availability & Clarity",
                value=2.0,
                evidence="No privacy policy link detected on owned content",
                confidence=0.7
            )

        return None  # Not applicable for social/marketplace content

    def _detect_contact_info(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect contact/business info availability"""
        text = (content.body + " " + content.title).lower()
        meta = content.meta or {}

        # Check metadata
        has_contact_meta = any(key in meta for key in ["contact_url", "email", "phone", "address"])

        # Check for email patterns (simple regex)
        has_email = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', text)

        # Check for phone patterns (very simple, to avoid false positives)
        # Look for "Call us: ..." or similar context if possible, but simple pattern for now
        # has_phone = re.search(r'\+?[\d\s-]{10,}', text) # Too risky for false positives

        # Check for "Contact Us" links/text
        contact_phrases = ["contact us", "get in touch", "customer support", "help center", "contact support"]
        has_contact_phrase = any(phrase in text for phrase in contact_phrases)

        if has_contact_meta or has_email or has_contact_phrase:
            return DetectedAttribute(
                attribute_id="contact_info_availability",
                dimension="transparency",
                label="Contact/Business Info Availability",
                value=10.0,
                evidence="Contact info or link found",
                confidence=0.9
            )
        
        return DetectedAttribute(
            attribute_id="contact_info_availability",
            dimension="transparency",
            label="Contact/Business Info Availability",
            value=2.0,
            evidence="No contact info detected",
            confidence=0.7
        )

    # ===== VERIFICATION DETECTORS =====

    def _detect_ad_labels(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect ad/sponsored label consistency"""
        text = (content.body + " " + content.title).lower()
        meta = content.meta or {}

        ad_labels = ["sponsored", "advertisement", "ad", "promoted", "paid partnership"]

        has_ad_label = (
            any(label in text for label in ad_labels) or
            meta.get("is_sponsored") == "true"
        )

        # Check for ad intent without proper labeling
        ad_intent_markers = ["buy now", "limited time offer", "discount code", "affiliate link"]
        has_ad_intent = any(m in text for m in ad_intent_markers)
        
        if has_ad_intent and not has_ad_label:
            return DetectedAttribute(
                attribute_id="ad_sponsored_label_consistency",
                dimension="verification",
                label="Ad/Sponsored Label Consistency",
                value=1.0,
                evidence="Commercial intent detected without visible ad disclosure",
                confidence=0.8
            )
        
        return None  # No issue detected

    def _detect_safety_guardrails(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect agent safety guardrails (placeholder)"""
        # TODO: Check for safety features in bot responses
        return None

    def _detect_claim_traceability(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect claim-to-source traceability"""
        # Reuse logic from _detect_citations since it covers the same ground
        # (detecting data claims and checking for citations)
        
        # We'll use a slightly stricter threshold or different logic if needed,
        # but for now, the core requirement is the same: claims need sources.
        
        # Call the existing citation detector
        citation_result = self._detect_citations(content)
        
        if not citation_result:
            return None
            
        # Map the result to the Verification dimension
        # If citations are missing (value < 10), it's a traceability issue
        
        # We only want to report this if there's an issue (value < 10)
        # or if we want to give credit for good traceability
        
        return DetectedAttribute(
            attribute_id="claim_to_source_traceability",
            dimension="verification",
            label="Claim traceability",  # Must match rubric.json
            value=citation_result.value,
            evidence=citation_result.evidence,
            confidence=citation_result.confidence
        )

    def _detect_engagement_authenticity(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect engagement authenticity ratio"""

        # Determine content type to check if engagement is expected
        content_type = self._determine_content_type(content)

        # Skip engagement detection for landing pages and promotional pages
        # where user engagement (upvotes, helpful counts) is not expected
        if content_type == 'landing_page':
            return None

        # Only apply engagement scoring to content types where it's meaningful
        # (blog, article, news, social_post)
        if content_type not in ['blog', 'article', 'news', 'social_post']:
            return None

        # Check for signs of authentic engagement
        upvotes = content.upvotes or 0
        helpful_count = content.helpful_count or 0

        # Simple heuristic: high engagement = likely authentic
        if upvotes > 100 or helpful_count > 10:
            value = 9.0
            evidence = f"High authentic engagement ({upvotes} upvotes, {helpful_count} helpful)"
        elif upvotes > 10:
            value = 7.0
            evidence = f"Moderate engagement ({upvotes} upvotes)"
        else:
            value = 5.0  # Neutral
            evidence = f"Low engagement ({upvotes} upvotes)"

        return DetectedAttribute(
            attribute_id="engagement_authenticity_ratio",
            dimension="verification",
            label="Engagement Authenticity Ratio",
            value=value,
            evidence=evidence,
            confidence=0.6
        )

    def _detect_influencer_verified(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect influencer/partner identity verification"""
        # Similar to author verification
        meta = content.meta or {}

        is_verified = (
            meta.get("influencer_verified") == "true" or
            meta.get("verified") == "true"
        )

        if is_verified:
            return DetectedAttribute(
                attribute_id="influencer_partner_identity_verified",
                dimension="verification",
                label="Influencer/Partner Identity Verified",
                value=10.0,
                evidence="Verified influencer/partner",
                confidence=1.0
            )
        return None

    def _detect_review_authenticity(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect review authenticity confidence"""
        text = (content.body + " " + content.title).lower()
        meta = content.meta or {}

        # 1. Amazon-specific logic (keep existing)
        if content.src == "amazon":
            is_verified = meta.get("verified_purchase") == "true"
            helpful_count = content.helpful_count or 0

            if is_verified and helpful_count > 5:
                value = 10.0
                evidence = "Verified purchase with helpful votes"
            elif is_verified:
                value = 8.0
                evidence = "Verified purchase"
            else:
                value = 5.0
                evidence = "Unverified purchase"
            
            return DetectedAttribute(
                attribute_id="review_authenticity_confidence",
                dimension="verification",
                label="Review Authenticity Confidence",
                value=value,
                evidence=evidence,
                confidence=0.7
            )

        # 2. General logic for other sites
        # Check for "Reviews" section or star ratings
        has_reviews_section = "reviews" in text or "customer reviews" in text
        
        # Look for "4.5 out of 5" or "4.5/5" patterns
        star_rating_match = re.search(r'(\d(?:\.\d)?)\s*(?:out of|/)\s*5', text)
        
        if has_reviews_section and star_rating_match:
            rating = float(star_rating_match.group(1))
            return DetectedAttribute(
                attribute_id="review_authenticity_confidence",
                dimension="verification",
                label="Review Authenticity Confidence",
                value=8.0, # Good confidence if we see ratings and review section
                evidence=f"Reviews section found with rating {rating}/5",
                confidence=0.6
            )
        elif has_reviews_section:
             return DetectedAttribute(
                attribute_id="review_authenticity_confidence",
                dimension="verification",
                label="Review Authenticity Confidence",
                value=6.0,
                evidence="Reviews section detected",
                confidence=0.5
            )

        return None

    def _detect_seller_verification(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect seller & product verification rate (placeholder)"""
        # TODO: Implement marketplace verification checking
        return None

    def _detect_verified_purchaser(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect verified purchaser review rate"""
        # Only applicable to Amazon reviews
        if content.src != "amazon":
            return None

        meta = content.meta or {}
        is_verified = meta.get("verified_purchase") == "true"

        if is_verified:
            return DetectedAttribute(
                attribute_id="verified_purchaser_review_rate",
                dimension="verification",
                label="Verified Purchaser Review Rate",
                value=10.0,
                evidence="Verified purchase badge present",
                confidence=1.0
            )
        else:
            return DetectedAttribute(
                attribute_id="verified_purchaser_review_rate",
                dimension="verification",
                label="Verified Purchaser Review Rate",
                value=3.0,
                evidence="No verified purchase badge",
                confidence=1.0
            )

    # ===== AI READINESS DETECTORS =====

    def _detect_schema_compliance(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect schema.org compliance"""
        meta = content.meta or {}

        # Check for schema.org structured data
        has_schema = any(key in meta for key in ["schema_org", "json_ld", "microdata", "rdfa"])
        schema_valid = meta.get("schema_valid") != "false"

        if has_schema and schema_valid:
            value = 10.0
            evidence = "Complete and valid schema.org markup present"
        elif has_schema:
            value = 7.0
            evidence = "Schema.org markup present but may be incomplete"
        else:
            value = 1.0
            evidence = "No schema.org structured data detected"

        return DetectedAttribute(
            label="Schema.org Compliance",
            value=value,
            evidence=evidence,
            confidence=0.9
        )

    def _detect_metadata_completeness(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect metadata completeness"""
        meta = content.meta or {}

        # Check for key metadata fields
        required_fields = ["title", "description", "author", "date", "keywords"]
        present_fields = []

        if content.title and len(content.title.strip()) > 0:
            present_fields.append("title")
        if content.body and len(content.body.strip()) > 100:  # Assume body contains description
            present_fields.append("description")
        if content.author and len(content.author.strip()) > 0:
            present_fields.append("author")
        if content.published_at:
            present_fields.append("date")
        if meta.get("keywords") or meta.get("tags"):
            present_fields.append("keywords")

        # Check OG tags
        has_og_tags = any(key.startswith("og_") for key in meta.keys())
        if has_og_tags:
            present_fields.append("og_tags")

        completeness = len(present_fields) / len(required_fields)
        value = 1.0 + (completeness * 9.0)  # Scale 1-10

        return DetectedAttribute(
            attribute_id="metadata_completeness",
            label="Metadata Completeness",
            value=value,
            evidence=f"{len(present_fields)}/{len(required_fields)} key metadata fields present",
            confidence=1.0
        )

    def _detect_llm_retrievability(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect LLM retrievability (indexability)"""
        meta = content.meta or {}

        # Check robots meta tag
        robots_content = meta.get("robots", "").lower()
        has_noindex = "noindex" in robots_content
        has_nofollow = "nofollow" in robots_content

        # Check if content is indexable
        if has_noindex:
            value = 1.0
            evidence = "Content has noindex directive - not retrievable by LLMs"
        elif has_nofollow:
            value = 5.0
            evidence = "Content has nofollow directive - limited retrievability"
        else:
            # Check if sitemap or other indexing signals exist
            has_sitemap = meta.get("in_sitemap") == "true"
            if has_sitemap:
                value = 10.0
                evidence = "Fully indexable with sitemap presence"
            else:
                value = 8.0
                evidence = "Indexable but no explicit sitemap signal"

        return DetectedAttribute(
            attribute_id="llm_retrievability",
            label="LLM Retrievability",
            value=value,
            evidence=evidence,
            confidence=0.9
        )

    def _detect_canonical_linking(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect canonical URL presence and validity"""
        meta = content.meta or {}

        canonical_url = meta.get("canonical_url") or meta.get("canonical")
        current_url = content.url

        if canonical_url:
            # Check if canonical matches current URL
            if canonical_url == current_url or canonical_url.rstrip('/') == current_url.rstrip('/'):
                value = 10.0
                evidence = "Canonical URL present and matches current URL"
            else:
                value = 5.0
                evidence = f"Canonical URL present but points elsewhere: {canonical_url}"
        else:
            value = 1.0
            evidence = "No canonical URL specified"

        return DetectedAttribute(
            attribute_id="canonical_linking",
            label="Canonical Linking",
            value=value,
            evidence=evidence,
            confidence=1.0
        )

    def _detect_indexing_visibility(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect indexing visibility (sitemap, robots.txt)"""
        meta = content.meta or {}

        has_sitemap = meta.get("has_sitemap") == "true" or meta.get("in_sitemap") == "true"
        robots_allowed = meta.get("robots_txt_allowed") != "false"
        has_noindex = "noindex" in meta.get("robots", "").lower()

        # Calculate score based on indexing signals
        if has_sitemap and robots_allowed and not has_noindex:
            value = 10.0
            evidence = "Sitemap present, robots.txt allows crawling, no noindex tag"
        elif robots_allowed and not has_noindex:
            value = 7.0
            evidence = "Indexable but no sitemap detected"
        elif has_noindex:
            value = 1.0
            evidence = "Noindex tag prevents indexing"
        else:
            value = 3.0
            evidence = "Limited indexing signals"

        return DetectedAttribute(
            attribute_id="indexing_visibility",
            label="Indexing Visibility",
            value=value,
            evidence=evidence,
            confidence=0.8
        )

    def _detect_ethical_training_signals(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect AI training opt-out/ethical signals"""
        meta = content.meta or {}

        # Check for TDM (Text and Data Mining) reservations
        has_tdm_reservation = any(key in meta for key in ["tdm_reservation", "ai_training_optout", "robots_tdm"])

        # Check robots.txt for AI crawler directives
        robots_txt = meta.get("robots_txt", "").lower()
        has_ai_directive = any(bot in robots_txt for bot in ["gptbot", "ccbot", "anthropic-ai", "claude-web"])

        if has_tdm_reservation or has_ai_directive:
            value = 10.0
            evidence = "Clear AI training opt-out or TDM reservation signals present"
        elif meta.get("copyright") or meta.get("rights"):
            value = 5.0
            evidence = "Copyright/rights metadata present (ambiguous AI training policy)"
        else:
            value = 1.0
            evidence = "No AI training policy or TDM reservation signals"

        return DetectedAttribute(
            attribute_id="ethical_training_signals",
            label="Ethical Training Signals",
            value=value,
            evidence=evidence,
            confidence=0.7
        )

    def _detect_ad_labels(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect ad/sponsored label consistency"""
        text = (content.body + " " + content.title).lower()
        
        # Check for ad intent markers without proper labeling
        ad_intent_markers = ["buy now", "limited time offer", "discount code", "affiliate link"]
        has_ad_intent = any(m in text for m in ad_intent_markers)
        
        proper_labels = ["ad", "sponsored", "paid partnership", "promoted"]
        has_proper_label = any(l in text for l in proper_labels)
        
        if has_ad_intent and not has_proper_label:
            return DetectedAttribute(
                attribute_id="ad_sponsored_label_consistency",
                dimension="verification",
                label="Ad/Sponsored Label Consistency",
                value=1.0,
                evidence="Commercial intent detected without visible ad disclosure",
                confidence=0.8
            )
        return None

    def _detect_safety_guardrails(self, content: NormalizedContent) -> Optional[DetectedAttribute]:
        """Detect agent safety guardrail presence"""
        # Only relevant for agent/bot content
        if content.modality != 'agent':
            return None
            
        # Check metadata for guardrail config
        meta = content.meta or {}
        if meta.get('safety_guardrails') == 'false':
             return DetectedAttribute(
                attribute_id="agent_safety_guardrail_presence",
                dimension="verification",
                label="Agent Safety Guardrail Presence",
                value=1.0,
                evidence="No safety guardrails configuration found",
                confidence=1.0
            )
        return None
