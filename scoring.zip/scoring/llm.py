"""
LLM Client for Classification

Minimal LLM client wrapper for classification prompts with caching.
Refactored to use the shared multi-provider ChatClient.
Prompts are imported from the centralized prompts module.
"""

import os
import json
import hashlib
import time
import re
from typing import List, Dict, Any

from scoring.llm_client import ChatClient
from prompts.classification import (
    CLASSIFICATION_SYSTEM,
    build_classification_prompt,
)

CACHE_DIR = os.path.join('.cache', 'llm')


class LLMClient:
    """LLM client wrapper for classification with file-based caching."""

    def __init__(self, model: str = 'gpt-4o', cache_dir: str = None, api_key: str = None):
        self.model = model or 'gpt-4o'
        self.cache_dir = cache_dir or CACHE_DIR
        os.makedirs(self.cache_dir, exist_ok=True)
        # Initialize ChatClient - it handles API keys from env if not provided
        self.chat_client = ChatClient(api_key=api_key, default_model=self.model)

    def _cache_path(self, key: str) -> str:
        h = hashlib.sha256(key.encode('utf-8')).hexdigest()
        return os.path.join(self.cache_dir, f"{self.model}.{h}.json")

    def _read_cache(self, key: str) -> Any:
        p = self._cache_path(key)
        if os.path.exists(p):
            try:
                with open(p, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return None
        return None

    def _write_cache(self, key: str, value: Any) -> None:
        try:
            with open(self._cache_path(key), 'w', encoding='utf-8') as f:
                json.dump(value, f)
        except Exception:
            pass

    def _call_llm(self, prompt: str) -> Dict[str, Any]:
        """Make LLM API call with few-shot classification prompt via ChatClient."""
        try:
            response = self.chat_client.chat(
                messages=[
                    {"role": "system", "content": CLASSIFICATION_SYSTEM},
                    {"role": "user", "content": prompt}
                ],
                model=self.model,
                temperature=0.1,
                max_tokens=200,
            )
            
            text = response.get('content', '').strip()
            
            if '```' in text:
                match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', text, re.DOTALL)
                if match:
                    return json.loads(match.group(1))
            return json.loads(text)
        except Exception:
            # Return raw text wrapped in dict on JSON parse failure (or empty if really broken)
            return {'raw': text} if 'text' in locals() else {}

    def classify(self, items: List[Dict[str, Any]], rubric_version: str = 'unknown') -> Dict[str, Dict[str, Any]]:
        """Classify a list of items."""
        results = {}
        
        for item in items:
            content_id = item.get('content_id', 'unknown')
            # Consistent cache key generation
            cache_key = f"{content_id}.{rubric_version}.{self.model}.{json.dumps(item.get('meta', {}), sort_keys=True)}.{item.get('final_score')}"
            
            cached = self._read_cache(cache_key)
            if cached is not None:
                results[content_id] = cached
                continue

            item_json = json.dumps(item, ensure_ascii=False, indent=2)
            prompt = build_classification_prompt(item_json)

            try:
                out = self._call_llm(prompt)
                if 'label' not in out or out.get('label') not in ['authentic', 'suspect', 'inauthentic']:
                    out = self._fallback_classification(item)
            except Exception as e:
                out = self._fallback_classification(item)
                out['notes'] = f"Fallback (error: {str(e)[:50]})"

            results[content_id] = out
            self._write_cache(cache_key, out)
            time.sleep(0.05)

        return results

    def _fallback_classification(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback classification based on final_score."""
        fs = float(item.get('final_score') or 0)
        if fs >= 75:
            return {'label': 'authentic', 'confidence': 0.7, 'notes': 'Score-based fallback'}
        elif fs >= 40:
            return {'label': 'suspect', 'confidence': 0.6, 'notes': 'Score-based fallback'}
        else:
            return {'label': 'inauthentic', 'confidence': 0.7, 'notes': 'Score-based fallback'}
